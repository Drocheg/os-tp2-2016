#ifndef SONGPLAYER_H
#define SONGPLAYER_H

void playSong();

#endif