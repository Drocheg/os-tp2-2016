#ifndef PIANO_H
#define PIANO_H

void piano();

#endif