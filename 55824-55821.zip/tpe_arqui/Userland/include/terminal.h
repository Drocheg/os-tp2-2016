#ifndef TERMINAL_H
#define TERMINAL_H

void runTerminal();

#endif