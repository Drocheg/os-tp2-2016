#ifndef VARGS_H
#define VARGS_H

typedef struct
{
	uint8_t count;
	void **args;
} vargs;

#endif