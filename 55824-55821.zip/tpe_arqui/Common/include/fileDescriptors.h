#ifndef FILE_DESCRIPTORS_H
#define FILE_DESCRIPTORS_H

#define STDIN 1
#define STDIN_RAW 2
#define STDOUT 3
#define STDERR 4
#define DATA_MODULE 5
#define MIN_FD STDIN
#define MAX_FD DATA_MODULE

#endif