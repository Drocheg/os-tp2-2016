#ifndef SCANCODES_H
#define SCANCODES_H

#include <stdint.h>

char decodeScanCode(uint8_t scanCode);

#endif